package com.example.ejemplo_coroutines

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PostViewModel : ViewModel() {

    private val _posts = MutableStateFlow<List<Post>>(emptyList())
    val posts: StateFlow<List<Post>> = _posts

    init {
        fetchPosts()
    }

    private fun fetchPosts() {
        viewModelScope.launch {
            try {
                Log.d("PostViewModel", "Iniciando fetch...")
                val response = withContext(Dispatchers.IO) {
                    RetrofitInstance.api.getPosts()
                }
                Log.d("PostViewModel", "Posts recibidos: ${response.size}")
                _posts.value = response
            } catch (e: Exception) {
                Log.e("PostViewModel", "Error al obtener posts", e)
            }
        }
    }
}

