package com.example.ejemplo_coroutines

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
                var error by remember { mutableStateOf<String?>(null) }

                LaunchedEffect(Unit) {
                    try {
                        posts = RetrofitInstance.api.getPosts()
                    } catch (e: Exception) {
                        error = "Error: ${e.message}"
                    }
                }

                if (error != null) {
                    Text(
                        text = error ?: "Error desconocido",
                        color = Color.Red
                    )
                } else if (posts.isEmpty()) {
                    Text("Cargando posts...")
                } else {
                    LazyColumn {
                        items(posts) { post ->
                            Text("${post.id}. ${post.title}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PostScreen(postViewModel: PostViewModel = viewModel()) {
    val posts = listOf(
        Post(1,1,"Título de prueba 1","Contenido de prueba 1"),
        Post(2,2,"Título de prueba 2","Contenido de prueba 2")
    )
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Posts desde API") })
        }
    ) { padding ->
        LazyColumn(contentPadding = padding) {
            items(posts) { post ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .clickable {
                            Toast.makeText(context, post.title, Toast.LENGTH_SHORT).show()
                        },
                    elevation = 4.dp
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(text = post.title, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = post.body, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}
